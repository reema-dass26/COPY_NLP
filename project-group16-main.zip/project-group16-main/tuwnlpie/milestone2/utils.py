
def get_X_y_from_csv(filename: str, data_path: str) -> (list[str], list[int]):
    import pandas as pd
    df = pd.read_csv(f'{data_path}/{filename}', index_col='id')
    print(f'loaded df from {data_path}/{filename} with {len(df.columns)} columns.')
    df.drop(df[df.text.str.strip().str.len() < 50].index, inplace=True)
    print(f'number of na values in the whole df: {df.isna().sum().sum()}')
    text = df['text'].to_list()
    label = df['label'].to_list()
    return (text, label)

def get_data() -> (list[str], list[int], list[str], list[int]):
    data_path = '../../data'
    # load the training data
    X_train, y_train = get_X_y_from_csv('dreaddit-train.csv', data_path)
    # load the test data
    X_test, y_test = get_X_y_from_csv('dreaddit-test.csv', data_path)
    return X_train, y_train, X_test, y_test
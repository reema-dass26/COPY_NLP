# dreaddit dataset

preprocessing

- some values only have `id	subreddit	post_id	sentence_range	text` and are missing the other fields
    - what do? drop? replace? --> see notebook
-  `social_timestamp` and `social_num_comments` are just time of posting and # of comments on the post
    - for example: late night post in r/anxiety might be more negative than a daytime post
    - for example: high # of comments might be controversial or outpouring of support, depending on the situation
- `sentence_range` describes which 5 sentences of a post have been selected. 
    - an example: posts are identified by their id and can be opened like this: `http://redd.it/{id}`
    - looking at `http://redd.it/6nxuex`: ![dataset table screenshot](../images/dataset_table_screenshot.png)
    - we can tell these rows were generated from a single post and labelled independent of each other. row 108 contains the text from the first 5 sentences, inclusive. the other rows do the same, just with different sequences of 5 sentences from the much longer post.
  
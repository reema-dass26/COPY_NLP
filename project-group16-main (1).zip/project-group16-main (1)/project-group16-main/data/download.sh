curl https://www.cs.columbia.edu/~eturcan/data/dreaddit.zip --output dreaddit.zip
unzip dreaddit.zip
rm dreaddit.zip
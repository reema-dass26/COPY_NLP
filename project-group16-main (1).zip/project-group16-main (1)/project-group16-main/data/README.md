## Datasets
- This folder should contain all the data you are going to use in your project. 
- Instead of puting the data directly to GitHub, you should provide a link to the data in the README.md file and instruct the user how to download the data.
- This is a good practice since usually we don't want to version control the data, but we want to version control the code that processes the data.

### The Dreaddit dataset
- The Dreaddit dataset is a dataset of corpus of lengthy multi-domain social media data for the identification of stress.
- It consists of 190K posts from five different categories of Reddit communities.
- source: [Dreaddit: A Reddit Dataset for Stress Analysis in Social Media](https://arxiv.org/pdf/1911.00133v1.pdf)

Download it using command line (on Windows, use git bash for compatability):

```bash
bash download.sh
```
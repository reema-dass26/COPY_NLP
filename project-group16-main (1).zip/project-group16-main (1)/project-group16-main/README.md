
# Natural Language Processing and Information Extraction 2023WS - Project

<img src="images/tuw_nlp.png" width="96"/>

# Project Description

## Summary

Task selection By the end of Week 2 (October 15) you must form groups of 4 and choose
your preferred projec topics. You may choose any of the tasks offered in Section 3 or any custom task that involves text classification and which has been approved by the exercise coordinator (see Section 3 for requirements and Section 5 for contact details). Registration of groups takes place via TUWEL, preferred topics can be selected using this form. Based on your selection your team will be assigned a mentor who will support you throughout the semester and evaluate each of your submissions. Your group will be added to a GitHub repository for pushing your submissions, details are in Section 2.

- Milestone 1: By the end of Week 5 (November 5) you shall have your core text datasets preprocessed and stored in a standard format. All code necessary for preprocessing must be pushed to your repository and briefly documented. More detail will be provided in the lecture on text processing (Week 2).
- Milestone 2: By the end of Week 9 (December 3) you shall implement multiple baseline solutions to your main text classification task. These should include both deep learning (DL) based methods such as those introduced in Weeks 5-6 but also non-DL models such as those shown in Week 3. Baselines can also include simple rule-based methods (e.g. keyword matching or regular expressions). Each baseline should be evaluated both quantitatively and qualitatively, more details will be provided in the lecture on text classification (Week 3)
- Final solution: Your final solution is due by the end of January 28. Final presentations will take place on January 19 (a week after the final lecture), the week after that should be reserved for improvements based on feedback from the presentation. Your final submission should include all your code with documentation, a management summary (see Section 2), and your presentation slides.

### Evaluation

Your final grade will be determined by scores given on the final solution (50%), the two milestones (15% each), the presentation, and the management summary (10% each). Note that the milestone scores will be based on the state of your repository at the time of each milestone deadline. The score for your final project will be based on its originality, the quality of your analysis and discussion, the quality of your code, and on overall impression. You will receive individual scores and feedback for each of these aspects. Milestone 1 and Milestone 2 must each be completed with a minimum score of 35% by their respective deadlines to pass the course. 

A note on expectations: In the second half of the semester the lectures will introduce approaches to modeling linguistic structure and meaning, then provide an overview of approaches to some of the most common tasks in NLP, some of which may be applicable to your chosen topic. For your final solution you are expected to conceive and implement approaches that go beyond the standard baselines implemented in the first half of the semester. The value of these solutions may come not only from superior quantitative performance but also from better explainability, broader applicability (e.g. different domains, less data), simplicity, efficiency, etc. You are encouraged to approach your mentor to discuss your ideas and get feedback. Extensive optimization of the metaparameters of machine learning models for small quantitative gains will not be highly valued.

## Additional Information

### Goals 

The topic descriptions in Section 3 provide many pointers and ideas for getting started,and indicate some challenges and questions that you can work on. You are not expected to addressmore than 1-2 of the challenges and questions listed, but the value of your project comes fromyour contributions to these (the implementation of standard methods with existing datasets canonly satisfy Milestones 1 and 2). Quantitative performance of a solution is only one indicator ofits value, based on the topic and the nature of your solution you may also need to consider aspectssuch as complexity, explainability, sustainability, risk of unintended bias, applicability (to multipledomains, datasets, or languages), etc.

### Datasets and languages

Each topic description makes some recommendations on datasets, butyou are encouraged to find additional resources. Using datasets in languages other than Englishor German that are understood by members of your group is encouraged, and so is working onmore than one language in the project. If you choose a language for which datasets are alreadyavailable, consider using at least two of them in the project. You may also choose a language withno datasets, in this case your main challenge will be to find possible ways to bootstrap a solutionand/or a dataset.

### Evaluation

Proper evaluation of methods, including your own, both quantitative (e.g. precisionand recall) and qualitative (e.g. looking at the data), is essential. For some tasks and some datasetsyou cannot assume that higher figures mean better solutions. Some manual analysis of a system’soutput is usually necessary to understand its strengths and limitations. Topic descriptions mayindicate task-specific challenges of evaluation.Technical details After teams registered for topics they will receive instructions on how tocreate their project repository using GitHub Classroom. Teams should then push their solutionsto this repository. The template repository will contain detailed instructions on how to structureyour code and documentation, you can preview it here. Your solution should be implemented inPython 3.7 or higher and should generally conform to PEP8 guidelines. You should also observeclean code principles.

### Management summary

Your submission must be accompanied by a 2-page PDF documentthat presents a summary of your solution — this is a management summary, so it should bewritten in a way that is easy to understand by top management, not NLP colleagues. The summaryshould contain an overview of the task, the challenges you faced, the external resources you used,the solution you implemented and its limitations, and possible next steps.

### Final Presentation

Each group will present the main results of their work to all other groupsworking on the same topic. The format is 20 minutes of presentation and 10 minutes ofdiscussion — we will be very strict with the timing, and stop the presentation at the 20 minutemark. Each team member must present their own contributions to their project,so that they can be evaluated individually. The presentation should be aimed at NLPcolleagues, so highlight which approaches and techniques you used, which data you used, and theinsights obtained. Presentation slides must be pushed to your project repository the day beforethe presentations. The schedule of presentations will be announced via TUWEL, please attend allpresentations in your section.


## Our Topic: Stress Detection

Instructor: Varvara Arzt

### Overview

The goal of this task is the classification of short utterances on social media (Reddit posts) to determine whether they contain stress.

### Resources

The Dreaddit dataset used for this task is available here. Please read the paper published about the dataset (Turcan and McKeown, 2019).

### Questions and challenges

- Thoroughly study the Dreaddit dataset and the way how it was created.
- Try to train a feature-based dicriminative classifier using additional metadata derived from Reddit such as posting time or number of comments (social timestamp and social num comments in .csv files containing the dataset) as well as LIWC information provided extra by the dataset authors. For more detail on the Linguistic Inquiry and Word Count (LIWC) see Pennebaker et al. (2015) as well as the initial paper that describes Dreaddit. The use of which features result in better model performance?
- Compare the results of a feature-based classifier with the results produced by a deep-learning model of your choise (e.g. a BERT-based model).
- Turcan and McKeown (2019) also describes both experiments with traditional supervised models like decision trees and neural models. Compare your results with those presented in paper.
- How can you make your classifier’s decisions explainable to users?

# Install and Quick Start

First create a new conda environment with python 3.10 and activate it:

```bash
conda create -n tuwnlpie python=3.10
conda activate tuwnlpie
```

Then install this repository as a package, the `-e` flag installs the package in editable mode, so you can make changes to the code and they will be reflected in the package.

```bash
pip install -e .
```

All the requirements should be specified in the `setup.py` file with the needed versions. If you are not able to specify everything there
you can describe the additional steps here, e.g.:

Install `black` library for code formatting:
```bash
pip install black
```

Install `pytest` library for testing:
```bash
pip install pytest
```

## The directory structure and the architecture of the project

```
📦project-2022WS
 ┣ 📂data
 ┃ ┣ 📜README.md
 ┃ ┣ 📜bayes_model.tsv
 ┃ ┣ 📜bow_model.pt
 ┃ ┗ 📜imdb_dataset_sample.csv
 ┣ 📂docs
 ┃ ┗ 📜milestone1.ipynb
 ┣ 📂images
 ┃ ┗ 📜tuw_nlp.png
 ┣ 📂scripts
 ┃ ┣ 📜evaluate.py
 ┃ ┣ 📜predict.py
 ┃ ┗ 📜train.py
 ┣ 📂tests
 ┃ ┣ 📜test_milestone1.py
 ┃ ┣ 📜test_milestone2.py
 ┣ 📂tuwnlpie
 ┃ ┣ 📂milestone1
 ┃ ┃ ┣ 📜model.py
 ┃ ┃ ┗ 📜utils.py
 ┃ ┣ 📂milestone2
 ┃ ┃ ┣ 📜model.py
 ┃ ┃ ┗ 📜utils.py
 ┃ ┗ 📜__init__.py
 ┣ 📜.gitignore
 ┣ 📜LICENSE
 ┣ 📜README.md
 ┣ 📜setup.py
```

- `data`: This folder contains the data that you will use for training and testing your models. You can also store your trained models in this folder. The best practice is to store the data elsewhere (e.g. on a cloud storage) and provivde download links. If your data is small enough you can also store it in the repository.
- `docs`: This folder contains the reports of your project. You will be asked to write your reports here in Jupyter Notebooks or in simple Markdown files.
- `images`: This folder contains the images that you will use in your reports.
- `scripts`: This folder contains the scripts that you will use to train, evaluate and test your models. You can also use these scripts to evaluate your models.
- `tests`: This folder contains the unit tests for your code. You can use these tests to check if your code is working correctly.
- `tuwnlpie`: This folder contains the code of your project. This is a python package that is installed in the conda environment that you created. You can use this package to import your code in your scripts and in your notebooks. The `setup.py` file contains all the information about the installation of this repositorz. The structure of this folder is the following:
  - `milestone1`: This folder contains the code for the first milestone. You can use this folder to store your code for the first milestone.
  - `milestone2`: This folder contains the code for the second milestone. You can use this folder to store your code for the second milestone.
  - `__init__.py`: This file is used to initialize the `tuwnlpie` package. You can use this file to import your code in your scripts and in your notebooks.
- `setup.py`: This file contains all the information about the installation of this repository. You can use this file to install this repository as a package in your conda environment.
- `LICENSE`: This file contains the license of this repository.
- `team.cfg`: This file contains the information about your team.


# Running the code

First download all the resources that you need for the project. You can find all the information in the `data/README.md` file. We also provide pretrained models for evaluation.

In the `scripts` folder you can find the scripts that you can use to train, evaluate and test your models. 

We have two scripts implemented for you:
- `train.py`: This script is used to train your models. It should expect a dataset file as an input and it should save the trained model in a file.

```bash
train.py [-h] -t TRAIN_DATA [-s] [-sp SAVE_PATH] [-m {1,2}]

optional arguments:
  -h, --help            show this help message and exit
  -t TRAIN_DATA, --train-data TRAIN_DATA
                        Path to training data
  -s, --save            Save model
  -sp SAVE_PATH, --save-path SAVE_PATH
                        Path to save model
  -m {1,2}, --milestone {1,2}
                        Milestone to train
```

- `evaluate.py`: This script is used to evaluate your models. It should expect a dataset file as an input and it should load the trained model from a file. The script should predict the labels for the dataset and it should print the accuracy metrics of the model.

```bash
evaluate.py [-h] -t TEST_DATA -sm SAVED_MODEL [-sp] [-m {1,2}]

optional arguments:
  -h, --help            show this help message and exit
  -t TEST_DATA, --test-data TEST_DATA
                        Path to test data
  -sm SAVED_MODEL, --saved-model SAVED_MODEL
                        Path to saved model
  -sp, --split          Split data
  -m {1,2}, --milestone {1,2}
                        Milestone to evaluate
```                        


## Run Milestone 1

[link to the notebook](tuwnlpie/milestone1/preprocessing.ipynb)

## Run Milestone 2

`TODO`

# Running the tests

For testing we use the `pytest` package (you should have it installed with the command provided above). You can run the tests with the following command:

```bash
pytest
```

# Code formatting

To convey a consistent coding style across the project, we advise using a code formatter to format your code.
For code formatting we use the `black` package (you should have it installed with the command provided above). You can format your code with the following command:

```bash
black .
```

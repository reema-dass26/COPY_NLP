# This file could contain a function that takes a model and a sentence and returns the predicted label.
# You could structure it the same way as the train or the evaluate scripts.
